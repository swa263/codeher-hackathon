var express= require("express");
var router=express.Router();
var Resource=require("../models/resource");



router.get("/", function(req, res){
    var noMatch = null;
    if(req.query.search) {
        const regex = new RegExp(escapeRegex(req.query.search), 'gi');
        // Get all campgrounds from DB
        Resource.find({name:regex}, function(err, allResources){
           if(err){
               console.log(err); 
           } else {
              if(allResources.length < 1) {
                  noMatch = "No resources match that query, please try again.";
              }
              res.render("resources/index",{resources:allResources, noMatch: noMatch});
           }
        });
    } else {
        // Get all campgrounds from DB
        Resource.find({}, function(err, allResources){
           if(err){
               console.log(err);
           } else {
              res.render("resources/index",{resources:allResources, noMatch: noMatch});
           }
        });
    }
});

//app.get is used to display the resources and app.post is used to add a new resource

// CREATE ROUTE- add new resource to DB
router.post("/",isLoggedIn,function(req,res){
	//get data from form and add to the restaurants page
	var name=req.body.name;
	var image=req.body.image;
	var quantity=req.body.quantity;
	var address=req.body.address;
	var desc=req.body.description;
	var author={
		id:req.user._id,
		username:req.user.username
	};
	var newResource={name:name,image:image,quantity:quantity,address:address,description:desc,author:author}
	//create a new resource and save to db
	Resource.create(newResource,function(err,newlyCreated){
		if(err){
			console.log(err);
		}
		else{
			//redirect back to resources page
			res.redirect("/resources");
		}
	});
});
//NEW:show form to create a new resource
router.get("/new",isLoggedIn,function(req,res){
	res.render("resources/new.ejs");
});

//SHOW -- shows more info about one resource
router.get("/:id",function(req,res){
	//find the resource with provided id
	Resource.findById(req.params.id).populate("comments").exec(function(err,foundResource){
		if(err){
			console.log(err);
		}
		else{
			//render show template with that resource
	res.render("resources/show",{resource: foundResource});
		}
	});
	
});


//edit resource route
router.get("/:id/edit",checkResourceOwnership,function(req,res){
	Resource.findById(req.params.id,function(err,foundResource){
		res.render("resources/edit",{resource:foundResource});
	});
});
//update resource route
router.put("/:id",checkResourceOwnership,function(req,res){
	//find and update the correct resource
	Resource.findByIdAndUpdate(req.params.id,req.body.resource,function(err,updatedResource){
		if(err){
			res.redirect("/resources");
			console.log(err);
		}else{
			//redirect to show page
			res.redirect("/resources/"+req.params.id);
		}
	});
	
});
//DESTROY RESOURCE ROUTE
router.delete("/:id",checkResourceOwnership,function(req,res){
	Resource.findByIdAndRemove(req.params.id,function(err){
		if(err){
			res.redirect("/resources");
		}else{
			res.redirect("/resources");
		}
	});
});

function isLoggedIn(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	res.redirect("/login")
}

function checkResourceOwnership(req,res,next){
	if(req.isAuthenticated()){
		Resource.findById(req.params.id,function(err,foundResource){
			if(err){
				res.redirect("back");
			} else{
				
				if(foundResource.author.id.equals(req.user._id)){
					next();
					
				}else{
					res.redirect("back");
				}
				
		}
	});
	}
	else{
		res.redirect("back");
	}
}	

function escapeRegex(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
};



module.exports=router;
